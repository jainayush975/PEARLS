
function hisFunction(cluster) {
    console.log(cluster);
        $.ajax({url: "http://127.0.0.1:8000/beads/?1", success: function(result){
            console.log(result);
            // console.log("ajax sucess");
            myFunction(result);
        }});
}



    // <div id="js"><button onclick()="threejscall()"> get graph </button></div>
    // <button onclick="myFunction()">Click me</button>
    //
    // <p id="demo"></p>

    // <script>

    function makeCircles(pointdic) {
        var geometry = new THREE.CircleGeometry( pointdic['r'], 100 );
        var material = new THREE.MeshBasicMaterial( {
            color: pointdic['c'],
            transparent: true,
            opacity: 0.5,
        } );
        var circle = new THREE.Mesh( geometry, material );
        circle.position.set(pointdic['x'], pointdic['y'], -5);
        return circle;
    }

    function plotPoint(circledic) {
        var geometry = new THREE.CircleGeometry( 0.01, 100 );
        var material = new THREE.MeshBasicMaterial( {
            color: circledic['c'],
        } );
        var circle = new THREE.Mesh( geometry, material );
        circle.position.set(circledic['x'], circledic['y'], -5);
        return circle;
    }

    function gogfunction() {
        result = {"shapes": {"0": {"y": -0.18765836891032806, "x": -0.077730641495471584, "s": 2, "r": 0.42068433372538955, "c": "#ff1f00"}, "1": {"y": 0.0, "x": 0.36969582091227421, "s": 2, "r": 0.37906317268878631, "c": "#1be21d"}, "2": {"y": -0.26023333173746238, "x": 0.62825883886211731, "s": 2, "r": 0.33166247903554141, "c": "#005eff"}}, "points": {"0": [{"y": -0.18765836891032806, "x": 0.039068225402465392, "c": "#ff1f00"}, {"y": -0.057962618577785785, "x": 0.051965108837070687, "c": "#ff1f00"}, {"y": 0.010325294214176772, "x": -0.07773064149547157, "c": "#ff1f00"}, {"y": -0.060558696977059512, "x": -0.38457639324993947, "c": "#ff1f00"}, {"y": -0.18765836891032806, "x": -0.16765516403013078, "c": "#ff1f00"}, {"y": -0.38242001494319655, "x": 0.1170310045373968, "c": "#ff1f00"}, {"y": -0.33909184858187336, "x": 0.073702838176073662, "c": "#ff1f00"}, {"y": -0.43772008968648113, "x": -0.077730641495471625, "c": "#ff1f00"}, {"y": -0.084238053580764985, "x": -0.12056873872987871, "c": "#ff1f00"}, {"y": -0.11746753462482191, "x": 0.091725022590879793, "c": "#ff1f00"}, {"y": -0.033898896653683647, "x": -0.07773064149547157, "c": "#ff1f00"}, {"y": 0.031275636592317302, "x": -0.2966646469981169, "c": "#ff1f00"}, {"y": -0.08944641235874537, "x": -0.31483527898949959, "c": "#ff1f00"}, {"y": -0.57678528019560438, "x": -0.077730641495471653, "c": "#ff1f00"}, {"y": -0.026669444138075094, "x": 0.31093100408156343, "c": "#ff1f00"}, {"y": -0.18765836891032803, "x": -0.29953580569188426, "c": "#ff1f00"}, {"y": -0.55625597814140293, "x": -0.077730641495471653, "c": "#ff1f00"}, {"y": -0.18765836891032806, "x": 0.20565715283468022, "c": "#ff1f00"}], "1": [{"y": -0.08921987902665024, "x": 0.15429997893284828, "c": "#1be21d"}, {"y": -0.11333333333333308, "x": 0.25636248757894109, "c": "#1be21d"}, {"y": -0.1379210724371816, "x": 0.36969582091227421, "c": "#1be21d"}, {"y": 0.19457603869976639, "x": 0.28909978676999876, "c": "#1be21d"}, {"y": 0.072294652438968043, "x": 0.54423055131747999, "c": "#1be21d"}, {"y": -0.11766241729815197, "x": 0.48735823821042612, "c": "#1be21d"}, {"y": -0.16446324378183935, "x": 0.43781872699858471, "c": "#1be21d"}, {"y": 0.19457603869976639, "x": 0.28909978676999876, "c": "#1be21d"}, {"y": 0.19457603869976639, "x": 0.28909978676999876, "c": "#1be21d"}, {"y": -0.25267458210996252, "x": 0.11702123880231163, "c": "#1be21d"}, {"y": -0.077508485695269025, "x": 0.18257378354775464, "c": "#1be21d"}, {"y": -0.1008849730028103, "x": 0.26881084790946386, "c": "#1be21d"}, {"y": -0.22025238048909013, "x": 0.149443440423184, "c": "#1be21d"}, {"y": -0.1196085555237927, "x": 0.65845641783366937, "c": "#1be21d"}, {"y": 4.6421850110796258e-17, "x": -0.0093673517765121006, "c": "#1be21d"}], "2": [{"y": -0.33094400985611699, "x": 0.5575481607434627, "c": "#005eff"}, {"y": -0.13921820482899472, "x": 0.92041519949684125, "c": "#005eff"}, {"y": -0.59189581077300379, "x": 0.6282588388621172, "c": "#005eff"}]}};
        myFunction(result);
    }

    function myFunction(result) {
        // document.getElementById("demo").innerHTML = "Hello World";
        console.log("boom1");

                    console.log("boom");

                                var renderer = new THREE.WebGLRenderer({
                                canvas: document.getElementById('mycanvas'),
                                antialias: true
                            })

                            renderer.setClearColor('#ffffff');
                            renderer.setPixelRatio(window.devicePixelRatio);
                            renderer.setSize(window.innerWidth*0.75, window.innerHeight*0.75);

                            var camera = new THREE.PerspectiveCamera(35, window.innerWidth/ window.innerHeight, 0.1, 3000);
                            var scene = new THREE.Scene();

                            // camera.poition.set(0,0,-3);

                            var material = new THREE.LineBasicMaterial({
                            	color: 0x0000ff,
                                linewidth: 1,
                            	// linecap: 'round', //ignored by WebGLRenderer
                            	// linejoin:  'round' //ignored by WebGLRenderer
                            });


                            for (var key in result['shapes']) {
                                var obj = makeCircles(result['shapes'][key]);
                                scene.add(obj);
                            }

                            for (var key in result['points']) {
                                var len = result['points'][key].length;
                                for (var i=0; i<len; i++) {
                                    var obj = plotPoint(result['points'][key][i]);
                                    scene.add(obj);
                                }


                            }

                            var gridHelper = new THREE.GridHelper( 3, 15, '#7386D5', '#7386D5' );
                            gridHelper.position.set(0, 0, -5);
                            gridHelper.geometry.rotateX(Math.PI/2.0);
                            scene.add( gridHelper );

                            var cameraz = 0;
                            var adder = 0;
                            // requestAnimationFrame(render);

                            renderer.render(scene, camera);
                            //         function render() {
                            //             // adder += 1;
                            //             // if(adder > 100) adder = 0;
                            //             // camera.position.set(0,0,cameraz+(adder/100));
                            //             requestAnimationFrame(render);
                            //         }
                            return 0;

    }


// var geometryx = new THREE.Geometry();
// var geometryy = new THREE.Geometry();
// geometryx.vertices.push(
//     new THREE.Vector3( -50, 0, -100 ),
//     new THREE.Vector3( 50, 0, -100 ),
//     // new THREE.Vector3( 10, 0, -100 )
// );
// geometryy.vertices.push(
//     new THREE.Vector3( 0, -50, -100 ),
//     new THREE.Vector3( 0, 50, -100 ),
//     // new THREE.Vector3( 10, 0, -100 )
// );
//
// var line1 = new THREE.Line( geometryx, material );
// var line2 = new THREE.Line( geometryy, material );
//
// scene.add( line1 );
// scene.add( line2 );
